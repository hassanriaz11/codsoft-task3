var typed= new typed(".text",{
    Strings:["Frontend Developer", "Data Analyst", "Java Programmer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay:1000,
    loop: true
}
);